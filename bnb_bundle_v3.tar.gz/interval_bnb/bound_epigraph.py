"""Per-box EPIGRAPH LP — the bound that closes the minimax-maximin gap.

Performance-critical. Implementation notes:
  * LP construction is fully vectorized via numpy (no Python for-loops).
  * Constraint matrix is built sparsely (scipy.sparse.csr_matrix) and
    passed directly to HiGHS — substantially faster than dense for the
    typical 80-90% sparsity of our constraint matrix.
  * A single LP solve per call returns BOTH the float optimum and the
    dual marginals, so caller can skip float pre-filter when going
    straight to integer cert.
  * Static "structure" of the LP (which entries are non-zero, which
    pairs (i,j) belong to which window's support) is cached per d via
    `_cache_lp_structure(windows, d)`.


This implements a single LP per box that rigorously lower-bounds
`min_{μ ∈ B ∩ Δ_d} max_W TV_W(μ)`. Unlike per-window or aggregate-CCTR
bounds, the epigraph LP couples ALL windows via shared McCormick lifts
Y_{i,j} and a single epigraph variable z.

LP formulation (variables: Y_{i,j} for all i,j ∈ [d], μ_i, z):
    min z
    s.t.  Y_{i,j} ≥ lo_j μ_i + lo_i μ_j − lo_i lo_j  (SW, ∀ i,j)
          Y_{i,j} ≥ hi_j μ_i + hi_i μ_j − hi_i hi_j  (NE, ∀ i,j)
          z      ≥ scale_W · Σ_{(i,j) ∈ S_W} Y_{i,j}   (epigraph, ∀ W)
          Σ μ_i = 1
          lo ≤ μ ≤ hi,  Y ≥ 0,  z ≥ 0.

SOUNDNESS: For μ ∈ B ∩ Δ_d ∩ {μ ≥ 0}, set Y_{i,j} = μ_i μ_j (feasible:
SW and NE faces hold pointwise on a non-negative box). Then Σ_{S_W} Y =
μ^T A_W μ, so z ≥ scale_W · μ^T A_W μ = TV_W(μ) for every W. Hence
z ≥ max_W TV_W(μ). The LP minimum over (μ, Y, z) is therefore ≤
min_{μ ∈ B} max_W TV_W(μ) — a valid LB.

THIS IS STRICTLY TIGHTER THAN per-window joint-face: per-window LP
gives `max_W min_B μ^T M_W μ` (maximin), while this LP gives
`min_B max_W μ^T M_W μ` (the actual minimax) up to McCormick relaxation
of the bilinear `μ_i μ_j → Y_{i,j}` step. The minimax-maximin gap that
caused the 99.05660% stall in BnB at d=10/d=20 is closed.

For RIGOR (integer-arithmetic certificate via Neumaier-Shcherbina):
solve the LP in scipy float, extract dual marginals, round to common
integer denominator, redistribute the rounding residual into bound
duals, then compute the certified LB in exact integer arithmetic.
"""
from __future__ import annotations

from fractions import Fraction
from typing import List, Sequence, Tuple

import numpy as np

from .box import SCALE as _SCALE
from .windows import WindowMeta

# Same conventions as bound_eval.py
_SCALE2 = _SCALE * _SCALE  # 2^120


# ---------------------------------------------------------------------
# LP-structure cache: per (id(windows), d) we precompute index arrays
# describing which (i,j,W) triples appear in which constraints. Only the
# numerical values (lo, hi) change per box, so the structure is reusable.
# ---------------------------------------------------------------------

_LP_STRUCT_CACHE: dict = {}


def _cache_lp_structure(windows, d: int):
    """Return per-window/per-pair structural index arrays for the
    epigraph LP. Cached by (id(windows), d).

    Returns:
      pair_i, pair_j: 1-D int arrays of length d² indexing pairs.
      window_pair_rows, window_pair_cols, window_pair_scales:
         CSR-like arrays for the epigraph rows. window_pair_rows[k] gives
         the window index (k_w), window_pair_cols[k] = yi(i,j) of the pair,
         window_pair_scales[k] = scale_W. Length = sum |pairs_all|.
    """
    key = (id(windows), d)
    got = _LP_STRUCT_CACHE.get(key)
    if got is not None:
        return got
    n_y = d * d
    # All pairs (i,j): row i*d+j, with i = idx//d, j = idx%d.
    pair_i = np.repeat(np.arange(d), d)
    pair_j = np.tile(np.arange(d), d)
    # Epigraph row entries: per window, per pair (i,j) ∈ S_W: contribute
    # +scale_W to A_ub[2*n_y + k_w, yi(i,j)].
    rows_w, cols_w, scales_w = [], [], []
    for k_w, w in enumerate(windows):
        s_W = float(w.scale)
        for (i, j) in w.pairs_all:
            rows_w.append(k_w)
            cols_w.append(i * d + j)
            scales_w.append(s_W)
    rows_w = np.asarray(rows_w, dtype=np.int64)
    cols_w = np.asarray(cols_w, dtype=np.int64)
    scales_w = np.asarray(scales_w, dtype=np.float64)
    out = (pair_i, pair_j, rows_w, cols_w, scales_w)
    _LP_STRUCT_CACHE[key] = out
    return out


def _solve_epigraph_lp(lo, hi, windows, d):
    """Solve the epigraph LP, return (lp_val, ineqlin, eqlin, lower, upper).

    Builds the constraint matrix VECTORIZED in csr-sparse format. Returns
    LP optimal value and dual marginals (for downstream rigor cert).
    Returns (lp_val=-inf, *None) if LP fails or infeasible.

    Variable layout: [Y_00..Y_{d-1,d-1} (n_y), μ_0..μ_{d-1} (d), z (1)].
    """
    from scipy.optimize import linprog
    from scipy.sparse import csr_matrix, coo_matrix
    n_y = d * d
    n_mu = d
    n_W = len(windows)
    n_vars = n_y + n_mu + 1
    z_idx = n_y + n_mu

    pair_i, pair_j, rows_w, cols_w, scales_w = _cache_lp_structure(windows, d)
    lo = np.asarray(lo, dtype=np.float64)
    hi = np.asarray(hi, dtype=np.float64)

    # Build A_ub in COO format then convert to CSR.
    # Row order: 0..n_y-1 = SW; n_y..2n_y-1 = NE; 2n_y..2n_y+n_W-1 = epigraph.
    # SW row r=yi(i,j):
    #   col yi(i,j): -1
    #   col mi(i)=n_y+i:  += lo[j]
    #   col mi(j)=n_y+j:  += lo[i]
    # NE row r=n_y + yi(i,j):
    #   col yi(i,j): -1
    #   col mi(i):   += hi[j]
    #   col mi(j):   += hi[i]
    # Epigraph row r=2n_y + k_w:
    #   col z_idx: -1
    #   col yi(i,j): += scale_W (for each (i,j) ∈ S_W)

    # Build COO entries:
    n_pairs = n_y
    # SW entries
    sw_rows = np.empty(3 * n_pairs, dtype=np.int64)
    sw_cols = np.empty(3 * n_pairs, dtype=np.int64)
    sw_data = np.empty(3 * n_pairs, dtype=np.float64)
    # block 0: (row=yi(i,j), col=yi(i,j), data=-1)
    sw_rows[:n_pairs] = np.arange(n_pairs)
    sw_cols[:n_pairs] = np.arange(n_pairs)
    sw_data[:n_pairs] = -1.0
    # block 1: (row=yi(i,j), col=n_y+i, data=lo[j])
    sw_rows[n_pairs:2 * n_pairs] = np.arange(n_pairs)
    sw_cols[n_pairs:2 * n_pairs] = n_y + pair_i
    sw_data[n_pairs:2 * n_pairs] = lo[pair_j]
    # block 2: (row=yi(i,j), col=n_y+j, data=lo[i])
    sw_rows[2 * n_pairs:3 * n_pairs] = np.arange(n_pairs)
    sw_cols[2 * n_pairs:3 * n_pairs] = n_y + pair_j
    sw_data[2 * n_pairs:3 * n_pairs] = lo[pair_i]

    # NE entries (rows offset by n_pairs)
    ne_rows = np.empty(3 * n_pairs, dtype=np.int64)
    ne_cols = np.empty(3 * n_pairs, dtype=np.int64)
    ne_data = np.empty(3 * n_pairs, dtype=np.float64)
    ne_rows[:n_pairs] = n_pairs + np.arange(n_pairs)
    ne_cols[:n_pairs] = np.arange(n_pairs)
    ne_data[:n_pairs] = -1.0
    ne_rows[n_pairs:2 * n_pairs] = n_pairs + np.arange(n_pairs)
    ne_cols[n_pairs:2 * n_pairs] = n_y + pair_i
    ne_data[n_pairs:2 * n_pairs] = hi[pair_j]
    ne_rows[2 * n_pairs:3 * n_pairs] = n_pairs + np.arange(n_pairs)
    ne_cols[2 * n_pairs:3 * n_pairs] = n_y + pair_j
    ne_data[2 * n_pairs:3 * n_pairs] = hi[pair_i]

    # Epigraph entries
    n_epi_pair_entries = len(rows_w)
    epi_rows = np.empty(n_epi_pair_entries + n_W, dtype=np.int64)
    epi_cols = np.empty(n_epi_pair_entries + n_W, dtype=np.int64)
    epi_data = np.empty(n_epi_pair_entries + n_W, dtype=np.float64)
    # pair contributions: row=2*n_y+k_w, col=yi(i,j), data=scale_W
    epi_rows[:n_epi_pair_entries] = 2 * n_pairs + rows_w
    epi_cols[:n_epi_pair_entries] = cols_w
    epi_data[:n_epi_pair_entries] = scales_w
    # z-column: row=2*n_y+k_w, col=z_idx, data=-1
    epi_rows[n_epi_pair_entries:] = 2 * n_pairs + np.arange(n_W)
    epi_cols[n_epi_pair_entries:] = z_idx
    epi_data[n_epi_pair_entries:] = -1.0

    rows_all = np.concatenate([sw_rows, ne_rows, epi_rows])
    cols_all = np.concatenate([sw_cols, ne_cols, epi_cols])
    data_all = np.concatenate([sw_data, ne_data, epi_data])
    n_ineq = 2 * n_pairs + n_W
    A_ub = coo_matrix((data_all, (rows_all, cols_all)),
                       shape=(n_ineq, n_vars)).tocsr()

    b_ub = np.empty(n_ineq, dtype=np.float64)
    # SW b_ub[yi(i,j)] = lo[i]*lo[j]
    b_ub[:n_pairs] = lo[pair_i] * lo[pair_j]
    # NE b_ub[n_y+yi(i,j)] = hi[i]*hi[j]
    b_ub[n_pairs:2 * n_pairs] = hi[pair_i] * hi[pair_j]
    # Epigraph: 0
    b_ub[2 * n_pairs:] = 0.0

    # A_eq: sum μ = 1.
    A_eq = csr_matrix(
        (np.ones(d), (np.zeros(d, dtype=np.int64),
                       n_y + np.arange(d))),
        shape=(1, n_vars),
    )
    b_eq = np.array([1.0])

    # Bounds
    bnds = [(0.0, None)] * n_y + [(float(lo[i]), float(hi[i])) for i in range(d)]
    bnds.append((0.0, None))  # z

    # Objective: c[z_idx] = 1
    c = np.zeros(n_vars)
    c[z_idx] = 1.0

    try:
        res = linprog(c, A_ub=A_ub, b_ub=b_ub, A_eq=A_eq, b_eq=b_eq,
                      bounds=bnds, method="highs")
    except Exception:
        return float("-inf"), None, None, None, None
    if not res.success:
        return float("-inf"), None, None, None, None
    return (
        float(res.fun),
        res.ineqlin.marginals if hasattr(res, 'ineqlin') else None,
        res.eqlin.marginals if hasattr(res, 'eqlin') else None,
        res.lower.marginals if hasattr(res, 'lower') else None,
        res.upper.marginals if hasattr(res, 'upper') else None,
    )


# ---------------------------------------------------------------------
# Float epigraph LP  (used as fast pre-filter and for diagnostics)
# ---------------------------------------------------------------------

def bound_epigraph_lp_float(
    lo: np.ndarray, hi: np.ndarray,
    windows: Sequence[WindowMeta], d: int,
) -> float:
    """Float LP value of the per-box epigraph relaxation. Returns -inf
    on LP failure. Uses the cached LP-structure path."""
    lp_val, *_ = _solve_epigraph_lp(lo, hi, windows, d)
    return lp_val


# ---------------------------------------------------------------------
# Rigorous integer-dual-certified epigraph cert
# ---------------------------------------------------------------------

def bound_epigraph_int_ge(
    lo_int: Sequence[int], hi_int: Sequence[int],
    windows: Sequence[WindowMeta], d: int,
    target_num: int, target_den: int,
    *, safety_only: bool = False,
) -> bool:
    """True iff the per-box epigraph LP value ≥ target_num / target_den,
    verified via integer dual certificate (Neumaier–Shcherbina pattern).

    If `safety_only=True`, skip the dual cert and rely on a SAFETY-MARGIN
    on the float LP value (sound modulo HiGHS LP arithmetic error;
    margin chosen at ≥ 1e3 × typical HiGHS relative error).

    Returns False on any LP failure (infeasibility, solver crash, etc.).
    """
    n_W = len(windows)
    if n_W == 0:
        return target_num <= 0
    n_y = d * d

    # Convert lo, hi to float for LP. Integer values used in dual cert.
    lo_f = np.array([li / _SCALE for li in lo_int], dtype=np.float64)
    hi_f = np.array([hv / _SCALE for hv in hi_int], dtype=np.float64)

    # Single LP solve (vectorized + sparse)
    lp_val, ineqlin, eqlin, lower_marg, upper_marg = _solve_epigraph_lp(
        lo_f, hi_f, windows, d,
    )
    if not np.isfinite(lp_val):
        return False

    target_f = target_num / target_den

    # Quick early-bail.
    if lp_val < target_f * (1.0 - 1e-9):
        return False

    if safety_only:
        # Sound modulo HiGHS relative error ~1e-10 to 1e-12. Margin
        # n_vars * 1e-14 is conservative.
        n_vars = n_y + d + 1
        n_ineq = 2 * n_y + n_W
        safety = max(n_vars + n_ineq, 100) * 1e-14
        return (lp_val - safety) >= target_f

    # ---- Integer dual certificate (Neumaier–Shcherbina) ----
    # scipy returns:
    #   ineqlin.marginals: 1D array of length n_ineq, all ≤ 0 (≤ ineqs).
    #   eqlin.marginals: 1D array of length 1, free.
    #   lower.marginals, upper.marginals: per-variable, sign convention
    #     where lower[i] ≥ 0 if active, upper[i] ≤ 0 if active (HiGHS).
    # We reconstruct the dual and verify primal LP value ≥ target via
    # weak duality, all in integer arithmetic at denom D_LP = _SCALE.

    D_LP = _SCALE  # 2^60

    def _round(x: float) -> int:
        return int(round(float(x) * D_LP))

    ineqlin_int = [_round(res.ineqlin.marginals[r]) for r in range(n_ineq)]
    eqlin_int = _round(res.eqlin.marginals[0])
    # Bound duals: HiGHS provides them. Sign:
    #  - lower.marginals[k] ≥ 0 means active lower bound.
    #  - upper.marginals[k] ≤ 0 means active upper bound.
    # We will recompute these from stationarity to avoid sign confusion.

    # Stationarity reconstruction:
    # For each variable v: c_v = -A_ub[:, v]^T · ineqlin + A_eq[:, v]^T · eqlin
    #                              + lower_dual_v - upper_dual_v
    # (With ineqlin ≤ 0, lower_dual ≥ 0, upper_dual ≥ 0, all summed with
    # signs that make scipy's LP dual feasible.)
    #
    # Rearranged:
    #   lower_dual_v - upper_dual_v
    #     = c_v + A_ub[:, v]^T · ineqlin - A_eq[:, v]^T · eqlin
    # Let r_v = c_v + A_ub[:, v]^T · ineqlin - A_eq[:, v]^T · eqlin.
    # Then we set lower_dual_v = max(r_v, 0), upper_dual_v = max(-r_v, 0).
    # This is dual-feasible (both ≥ 0).
    #
    # Certified LB:
    #   LB = b_eq · eqlin_int + (-b_ub) · ineqlin_int       (negate b_ub*ineqlin since ineqlin ≤ 0)
    #       + Σ_v lower[v] · lower_dual_v + Σ_v (-upper[v]) · upper_dual_v
    # Because lower bound is l_v · lower_dual_v (positive contribution
    # if l_v ≥ 0 and lower_dual_v ≥ 0), and upper bound contributes
    # -u_v · upper_dual_v (with upper_dual_v ≥ 0, u_v ≥ 0 ⇒ negative).
    #
    # Note: when computing in INTEGER arithmetic with ineqlin_int (denom
    # D_LP), eqlin_int (denom D_LP), and b_ub at denom _SCALE2 (since b_ub
    # has products lo_i * lo_j or hi_i * hi_j, both at denom _SCALE^2),
    # the products live at denom _SCALE2 * D_LP.

    # Precompute integer b_ub at denom _SCALE2.
    # SW b_ub[i,j] = lo_int[i] * lo_int[j]  (denom _SCALE2).
    # NE b_ub[i,j] = hi_int[i] * hi_int[j]  (denom _SCALE2).
    # Epigraph b_ub[k] = 0.

    # Compute residual r_v at each primal variable v (denom matters).
    # We work with all duals at denom D_LP. We will scale b_ub up to denom
    # D_LP * _SCALE2 by multiplying through.

    # For each Y_{i,j} (n_y of them):
    #   c_Y = 0.
    #   A_ub[:, Y_{i,j}] entries:
    #     - SW row yi(i,j):    coef = -1.
    #     - NE row n_y+yi(i,j): coef = -1.
    #     - epigraph row 2n_y + k_w: coef = scale_W (if (i,j) in S_W, else 0).
    #   A_eq[:, Y] = 0.
    # So r_Y = 0 + (-1)*sw_dual + (-1)*ne_dual + Σ_W scale_W * epi_dual_W (where (i,j) ∈ S_W).
    #         (note: ineqlin at denom D_LP, scale_W is rational with denom = w.scale_q.denominator)
    #
    # To avoid dealing with rational scale_W in integer mode, we will USE
    # the FRACTION scale_q for each window in the residual computation,
    # multiplying through by the LCM of all scale_q denominators (often
    # small: ell ranges 2..2d).
    #
    # Compute scale_lcm:
    scale_dens = [w.scale_q.denominator for w in windows]
    from math import lcm as _lcm
    scale_lcm = 1
    for x in scale_dens:
        scale_lcm = _lcm(scale_lcm, x)
    # Now each scale_W * scale_lcm is an integer = scale_q.numerator * scale_lcm / scale_q.denominator
    # ... but scale_q.numerator / scale_q.denominator might not have nice gcd.
    # Let scale_int_W = scale_q.numerator * (scale_lcm // scale_q.denominator)
    # Then scale_W = scale_int_W / scale_lcm.
    scale_int = []
    for w in windows:
        sq = w.scale_q
        scale_int.append(sq.numerator * (scale_lcm // sq.denominator))

    # Now all duals at denom D_LP, scale at denom scale_lcm. Common denom
    # for residual: D_LP * scale_lcm. Multiply ineqlin_int by scale_lcm
    # for non-epigraph rows (no scale factor); epigraph rows already
    # contribute scale_int at denom scale_lcm.
    #
    # r_Y[i,j] (at denom D_LP * scale_lcm)
    #   = c_Y * D_LP * scale_lcm    (= 0)
    #   - A_ub[SW yi(i,j)] = -1 contribution: -1 * sw_dual_int * scale_lcm
    #   - A_ub[NE yi(i,j)] = -1 contribution: -1 * ne_dual_int * scale_lcm
    #   + epigraph rows: scale_int_W * epi_dual_int_W (this row's coef on Y_{i,j})
    #     summed over W where (i,j) ∈ S_W
    #   - A_eq[Y] · eqlin = 0
    # So r_Y = -(sw_dual_int + ne_dual_int) * scale_lcm
    #          + Σ_{W: (i,j) ∈ S_W} scale_int_W * epi_dual_int_W
    #
    # CAUTION: the scipy dual sign for ≤ ineqs is ineqlin_marginals ≤ 0.
    # Standard convention: A_ub x ≤ b_ub with dual λ ≥ 0 in primal
    # convention (max c^T x = -min). To avoid sign flips, we use
    # |ineqlin| convention: define ineqlin_pos = -ineqlin_int (now ≥ 0).

    # Re-extract with sign flip for clarity:
    sw_pos = [-_round(res.ineqlin.marginals[yi(i, j)])
              for i in range(d) for j in range(d)]  # n_y values
    ne_pos = [-_round(res.ineqlin.marginals[n_y + yi(i, j)])
              for i in range(d) for j in range(d)]
    epi_pos = [-_round(res.ineqlin.marginals[2 * n_y + k_w])
               for k_w in range(n_W)]
    nu_int = _round(res.eqlin.marginals[0])

    # Sign feasibility: each *_pos must be ≥ 0 (since ineqlin ≤ 0, neg → pos).
    # Round-off may push negative; floor at 0 (sound: smaller dual gives
    # weaker but valid LB).
    sw_pos = [max(x, 0) for x in sw_pos]
    ne_pos = [max(x, 0) for x in ne_pos]
    epi_pos = [max(x, 0) for x in epi_pos]
    # nu_int is FREE (eq dual unconstrained); keep sign.

    # Stationarity for z: c_z = 1
    # A_ub[:, z] entries: only epigraph rows have coef -1 on z.
    # 1 = -Σ_W (-1) * (-epi_pos_W) + 0 * eq + lower_z - upper_z   (eq has no z)
    # Wait, scipy convention: A x ≤ b with dual μ ≥ 0 gives Lagrangian
    #   L = c^T x + μ^T (A x - b) = (c + A^T μ)^T x - μ^T b.
    # Stationarity: c + A^T μ = 0 (free vars) or split between bound duals.
    # With ineqlin = -μ (since scipy returns ≤ 0 marginals), we get
    #   c - A^T ineqlin_pos + A_eq^T nu = lower_dual - upper_dual.
    # (Where lower_dual ≥ 0, upper_dual ≥ 0.)
    #
    # For z: c_z = 1, A_ub[:, z] = -1 only at epi rows.
    #   1 - (-1) * epi_pos_total + 0 = lower_z - upper_z
    #   1 + Σ_W epi_pos_W = lower_z - upper_z
    # Since z has lower bound 0 (and no upper), lower_z ≥ 0, upper_z = 0.
    # So lower_z = 1 + Σ_W epi_pos_W ≥ 1 > 0. ✓

    # For Y_{i,j}: c_Y = 0.
    #   0 - [(-1) * sw_pos_ij + (-1) * ne_pos_ij + Σ_W (scale_W * (if (i,j) in S_W) epi_pos_W)]
    #   + 0 = lower_Y - upper_Y
    # I.e. lower_Y - upper_Y = -[sw_pos + ne_pos] - Σ_{W: (i,j) ∈ S_W} scale_W * epi_pos_W
    #                       + ... wait sign error.
    # Re-derive: A_ub[SW row, Y_{i,j}] = -1. So -A_ub[:, Y_{i,j}]^T · ineqlin_pos
    #     = -(-1) * sw_pos[i,j] + -(-1) * ne_pos[i,j] + -(scale_W) * epi_pos for relevant W
    #     = sw_pos + ne_pos - Σ_{W: (i,j) ∈ S_W} scale_W * epi_pos_W
    # Plus c_Y = 0 + A_eq^T·nu = 0:
    #   lower_Y - upper_Y = sw_pos[i,j] + ne_pos[i,j] - Σ_W scale_W * epi_pos_W (over (i,j) ∈ S_W)
    # Y has lower bound 0, no upper. So upper_Y = 0, lower_Y = above.
    # For dual feasibility lower_Y ≥ 0:
    #   sw_pos + ne_pos ≥ Σ_W scale_W * epi_pos_W  (over (i,j) ∈ S_W)
    # If this fails after rounding, we have a sign-infeasible certificate.
    # Fix: subtract the violation from epi_pos_W proportionally (sound:
    # smaller dual = weaker but valid LB).
    # For now: if violated, ABORT (safer). User sees False and box splits.

    # Working at denom D_LP * scale_lcm to absorb scale_W:
    # All dual quantities scaled by scale_lcm, scale_W replaced by scale_int.
    # lower_Y_int (at denom D_LP * scale_lcm)
    #   = (sw_pos[i,j] + ne_pos[i,j]) * scale_lcm
    #     - Σ_{W: (i,j) ∈ S_W} scale_int_W * epi_pos_W
    lower_Y = [0] * n_y
    for i in range(d):
        for j in range(d):
            idx = yi(i, j)
            v = (sw_pos[idx] + ne_pos[idx]) * scale_lcm
            # Subtract scale * epi_pos for windows containing (i,j)
            for k_w, w in enumerate(windows):
                if (i, j) in w.pairs_all_set if hasattr(w, 'pairs_all_set') else (i, j) in set(w.pairs_all):
                    v -= scale_int[k_w] * epi_pos[k_w]
            lower_Y[idx] = v
    # Soundness restoration: if any lower_Y[idx] < 0, the rounded duals
    # are not feasible. Reduce epi_pos uniformly by smallest fraction
    # needed (still sound — gives weaker LB).
    # (For simplicity: if any < 0, return False — split the box.)
    if any(v < 0 for v in lower_Y):
        return False

    # For μ_i: c_{μ_i} = 0.
    # A_ub[:, μ_i] entries:
    #   SW rows: (lo_j contributions where (i,j) is the row's pair —
    #      actually the SW row at (a,b) has A_ub[mi(a)] += lo_b and
    #      A_ub[mi(b)] += lo_a. So column μ_i is hit by SW rows
    #      where the pair has either i=a (coef lo_b) or i=b (coef lo_a)).
    #   NE rows: same with hi.
    #   Epigraph rows: 0 (z column only).
    # A_eq[:, μ_i] = 1 (the sum-1 constraint).
    #
    # r_{μ_i} (at denom D_LP * scale_lcm * _SCALE):
    #   = 0 - [Σ_(a,b) such that a==i or b==i: SW_row contribution to μ_i col * sw_pos
    #          + same for NE]
    #     - 1 * nu_int * (scale_lcm * _SCALE)   (eq dual at denom D_LP, scaled up to D_LP * scale_lcm * _SCALE)
    # With sw_pos at denom D_LP, scale up to denom D_LP * scale_lcm:
    #   sw_pos * scale_lcm. Multiplied by lo_int[j] / _SCALE: at denom D_LP * scale_lcm * _SCALE.
    # So (with all at denom D_LP * scale_lcm * _SCALE):
    #   r_μ_i = - Σ_(i,j): SW rows contribute lo_int[j] * sw_pos[yi(i,j)] * scale_lcm
    #            - Σ_(j,i): SW rows contribute lo_int[j] * sw_pos[yi(j,i)] * scale_lcm
    #            (equiv: pair (a,b) with a=i contributes lo_int[b] * sw_pos[yi(a,b)],
    #                   pair (a,b) with b=i contributes lo_int[a] * sw_pos[yi(a,b)])
    #   - same for NE with hi_int
    #   - nu_int * scale_lcm * _SCALE
    #   = lower_μ_i - upper_μ_i
    grand_denom = D_LP * scale_lcm * _SCALE
    r_mu = [0] * d
    for i in range(d):
        v = 0
        # SW contributions: row (a,b) has coef lo_b on μ_a col, lo_a on μ_b col.
        for a in range(d):
            for b in range(d):
                idx = yi(a, b)
                if a == i:
                    v -= lo_int[b] * sw_pos[idx] * scale_lcm
                if b == i:
                    v -= lo_int[a] * sw_pos[idx] * scale_lcm
                if a == i:
                    v -= hi_int[b] * ne_pos[idx] * scale_lcm
                if b == i:
                    v -= hi_int[a] * ne_pos[idx] * scale_lcm
        v -= nu_int * scale_lcm * _SCALE
        r_mu[i] = v
    # μ has finite [lo, hi] bounds. lower_μ_i = max(r_mu_i, 0),
    # upper_μ_i = max(-r_mu_i, 0).

    # Compute certified LB (at denom grand_denom).
    # LB = b_eq · nu - b_ub · ineqlin + Σ_v l_v · lower_dual_v + Σ_v (-u_v) · upper_dual_v
    # In our convention with sw_pos/ne_pos/epi_pos = -ineqlin (positive):
    # LB = 1 · nu_int - Σ_r (-1)·b_ub_r·dual_r ... actually
    #   LP duality (min): primal LP_val = max over duals of (b_eq·ν - b_ub·λ + l·η_l - u·η_u)
    #   where λ = -ineqlin (≥ 0), η_l = lower_dual, η_u = upper_dual.
    # LB = 1 · nu - Σ b_ub · (-ineqlin_int) + Σ l · lower_dual - Σ u · upper_dual
    #    = nu_int * (...) - Σ b_ub_r * (sw_pos or ne_pos or epi_pos)
    #      + Σ_v l_v * lower_dual_v - Σ_v u_v * upper_dual_v
    # Now b_eq·ν: nu_int * 1, at denom D_LP. Scale up to grand_denom by *(scale_lcm * _SCALE).
    # b_ub for SW (i,j): lo_int[i] * lo_int[j], at denom _SCALE^2. Multiplied by sw_pos (denom D_LP):
    #   product at denom _SCALE^2 * D_LP. Scale up to grand_denom by *(scale_lcm).
    # b_ub for NE (i,j): hi_int[i] * hi_int[j] at denom _SCALE^2.
    # b_ub for epigraph W: 0.
    # l for Y_{i,j}: 0. (No contribution.)
    # l for μ_i: lo_int[i] (denom _SCALE). lower_μ_i (denom D_LP * scale_lcm).
    #   Product: lo_int[i] * lower_μ_i. At denom _SCALE * D_LP * scale_lcm = grand_denom. ✓
    # l for z: 0 (z lower bound 0). No contribution.
    # u for Y_{i,j}: None (no upper). Skip.
    # u for μ_i: hi_int[i]. Product hi_int[i] * upper_μ_i.
    # u for z: None. Skip.

    LB_int = 0
    # b_eq · nu  (factor _SCALE * scale_lcm to lift D_LP to grand_denom)
    LB_int += nu_int * scale_lcm * _SCALE
    # - Σ b_ub · (sw_pos / ne_pos)  (factor scale_lcm to lift D_LP * _SCALE^2 to grand_denom)
    for i in range(d):
        for j in range(d):
            idx = yi(i, j)
            LB_int -= lo_int[i] * lo_int[j] * sw_pos[idx] * scale_lcm
            LB_int -= hi_int[i] * hi_int[j] * ne_pos[idx] * scale_lcm
    # epigraph b_ub = 0, no contribution.
    # μ bounds:  l · lower - u · upper.
    # Note r_mu = lower - upper. We split: lower = max(r,0), upper = max(-r,0).
    # Then l · lower - u · upper = l · max(r,0) - u · max(-r,0).
    # If r ≥ 0: contribution = l · r.
    # If r < 0: contribution = -u · (-r) = u · r (negative).
    # In both cases: contribution = (l if r ≥ 0 else u) * r.
    # Wait let me recheck: if r < 0, lower=0, upper=-r=|r|. Then l*0 - u*|r| = -u*|r| = u*r (since r<0).
    # Yes, contribution = (l if r ≥ 0 else u) * r.
    for i in range(d):
        r = r_mu[i]
        if r >= 0:
            LB_int += lo_int[i] * r  # already at grand_denom
        else:
            LB_int += hi_int[i] * r

    # Y bounds (lower=0): contribution from lower bound = 0 * lower_Y_v = 0. Skip.
    # Z bound: lower = 1 + Σ_W epi_pos_W (must be ≥ 0; trivially is). Lower bound on z = 0,
    # so contribution = 0 * lower_z = 0. Skip.

    # Compare LB_int / grand_denom ≥ target_num / target_den.
    # i.e., LB_int * target_den ≥ target_num * grand_denom.
    lhs = LB_int * target_den
    rhs = target_num * grand_denom
    return lhs >= rhs
